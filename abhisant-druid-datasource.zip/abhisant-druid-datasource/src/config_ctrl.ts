///<reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />

export class DruidConfigCtrl {
  static templateUrl = 'partials/config.html';
  current: any;

  constructor($scope) {
  }
}
